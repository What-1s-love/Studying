#pragma once
#include <cmath>

class Circle {
private:
    double radius;

public:
    void setRadius(double r);
    double getRadius();
    double getInscribedSquareSide();
    double getCircumscribedSquareSide();
};
