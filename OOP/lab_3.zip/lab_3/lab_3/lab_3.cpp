﻿#include <iostream>
#include "Circle.h"

using namespace std;

int main() {
    Circle A;
    A.setRadius(5);

    cout << "Radius of circle = " << A.getRadius() << endl;
    cout << "Side of inscribed square = " << A.getInscribedSquareSide() << endl;
    cout << "Side of circumscribed square = " << A.getCircumscribedSquareSide() << endl;

    Circle B;
    B.setRadius(7);

    cout << "\nRadius of circle = " << B.getRadius() << endl;
    cout << "Side of inscribed square = " << B.getInscribedSquareSide() << endl;
    cout << "Side of circumscribed square = " << B.getCircumscribedSquareSide() << endl;

   
    return 0;
}
