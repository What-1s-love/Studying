#include "Circle.h"

void Circle::setRadius(double r) {
    radius = r;
}

double Circle::getRadius() {
    return radius;
}

double Circle::getInscribedSquareSide() {
    return radius * sqrt(2);
}

double Circle::getCircumscribedSquareSide() {
    return 2 * radius;
}
